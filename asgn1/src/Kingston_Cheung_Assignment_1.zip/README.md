I used chatgpt ask for an example of rotation code looks like
https://chatgpt.com/share/696d997f-209c-8010-8934-4fe3a5da658f